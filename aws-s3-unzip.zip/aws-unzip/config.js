module.exports = {
    S3: {
        bucketName: 'orchestrators',
        region: 'us-east-2'
    }
}
